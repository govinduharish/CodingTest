import React from 'react';
import './style.css';
import { useEffect, useState } from 'react';

export default function App() {
  const [photos, setPhotos] = useState([]);
  const [clicked, setClicked] = useState(false);
  const [data, setData] = useState([]);
  const [text, setText] = useState('Compare');
  const [table, setTable] = useState([]);
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/photos')
      .then((res) => res.json())
      .then((data) => setPhotos(data));
  }, []);
  useEffect(() => {
    let arr = [];
    for (let j = 0; j < 2; j++) {
      arr.push({ ...photos[j], btnClicked: false });
      setData(arr);
    }
  }, [photos]);
  const handleCompare = (id) => {
    setClicked(!clicked);
    setText('Remove');
    let arr = [...table];
    arr.push(id);

    setTable(arr);
  };

  const hanldeRemove = (id) => {
    setClicked(!clicked);
    setText('Compare');
    let result = data.filter((item) => {
      return item.id != id.id;
    });
    setTable(result);
  };
  return (
    <div>
      <h1>Photo Listing</h1>
      <div>
        {data &&
          data.map((photo, index) => {
            return (
              <div key={index} style={{ flexWrap: 'wrap', marginTop: '20px' }}>
                <img src={photo && photo.thumbnailUrl} />
                <p>{photo && photo.title}</p>
                <p>{photo && photo.id}</p>
                <p>{photo && photo.url}</p>
                <button
                  onClick={
                    text == 'Compare'
                      ? () => handleCompare(photo)
                      : () => hanldeRemove(photo)
                  }
                >
                  {text}
                </button>
              </div>
            );
          })}
      </div>

      <table style={{ border: '1px solid green', marginTop: '20px' }}>
        <tr>
          <th>S.no</th>
          <th>ID</th>
          <th>URL</th>
          <th>Title</th>
        </tr>

        {table &&
          table.map((item, index) => {
            return (
              <tr key={index}>
                <td>{`Photo ${index + 1}`}</td>
                <td>{item.id}</td>
                <td>{item.url}</td>
                <td>{item.title}</td>
              </tr>
            );
          })}
      </table>
    </div>
  );
}
